package com.ives.cn;

import android.app.Activity;

import com.ives.cn.sofia.Bar;
import com.ives.cn.sofia.Sofia;

/**
 * @author 张海洋
 * @Date on 2019/05/10.
 * @org 上海..科技有限公司
 * @describe
 */
public class XUtil {
    /**
     * 状态栏使用
     */
    public static Bar getStatusBar(Activity activity) {
        return Sofia.with(activity);
    }

}
